<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><title>Partner | Business 2000</title><meta content="width=device-width,initial-scale=1" name="viewport"><meta content="" name="keywords"><meta content="" name="description"><!-- Favicons --><link href="img/favicon.png" rel="icon"><link href="img/apple-touch-icon.png" rel="apple-touch-icon"><!-- Google Fonts --><link href="https://fonts.googleapis.com/css?family=Michroma|Montserrat" rel="stylesheet"><!-- Bootstrap CSS File --><link href="lib/bootstrap/css/bootstrap.min.css" rel="stylesheet"><!-- Libraries CSS Files --><link href="lib/font-awesome/css/font-awesome.min.css" rel="stylesheet"><link href="lib/animate/animate.min.css" rel="stylesheet"><!-- Main Stylesheet File --><link href="assets/css/style.min.css" rel="stylesheet"><!-- =======================================================
    Theme Name: Regna
    Theme URL: https://bootstrapmade.com/regna-bootstrap-onepage-template/
    Author: BootstrapMade.com
    License: https://bootstrapmade.com/license/
  ======================================================= --></head><body> <?php include('inc/header.php'); ?> <!--==========================
    Home Section
  ============================--><section id="home"><div class="home-container"><h1>Business 2000</h1><h2>Your Network</h2><h3>Partner</h3></div></section><!-- #hero --><main id="main"><!--==========================
      About Us Section
    ============================--><section id="about"><div class="container"><div class="row about-container"><div class="col-lg-12 content order-lg-1 order-2"><h2 class="text-center">Ja Sie sehen richtig<br>Diese Seite ist noch im Aufbau</h2><center><img src="img/under-construction.jpg" alt="Under Construction"></center></div></div></div></section><!-- #about --><!--==========================
      Facts Section
    ============================--></main> <?php include('inc/footer.php') ?></body></html>